/** Automatically generated file. DO NOT MODIFY */
package com.example.broadcasttest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}